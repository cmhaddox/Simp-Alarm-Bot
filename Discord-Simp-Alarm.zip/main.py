import discord
import os

from run_always import run_always

client = discord.Client()

simp_counter = 269

@client.event
async def on_ready():
    print('We have logged in as {0.user}'.format(client))

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content.startswith('stogies'):
        await message.channel.send('"Because after dinner, everyone ought to have a cigar." So I tried it, well, the rest is history: I\'m still smoking stogies, I love it, and he introduced me to something really good. And I know now the next question! Knowing you, being the interviewer that you are, digging in deep all the time, you will say now, "What does your wife think about that?" Let me ask you something: when my wife\'s father has introduced me to stogies, what is she going to say? She is not going to say, "my father made a mistake," because her father never makes a mistake, so therefore it is okay. I can smoke stogies around her, I can smoke stogies in my house – first of all because her father introduced me to stogies, and second of all because I\'m a stud. I\’m ballsy. I don\’t take no shit from anyone. I smoke my stogie anywhere I want! I don\’t have to find a hideout place like you! Oh ho ho ho!')

    if message.author.id == 142434617050267658:
        if message.content.upper() == 'SARHANA':
          global simp_counter
          simp_counter += 1
          await message.channel.send('🚨 YOU\'VE SIMPED {} TIMES. SIMP! 🚨'.format(simp_counter))

run_always()

client.run(os.getenv('TOKEN'))